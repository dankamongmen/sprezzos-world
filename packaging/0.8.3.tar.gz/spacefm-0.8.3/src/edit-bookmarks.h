/*
*  C Interface: editbookmark
*
* Description:
*
*
* Author: Hong Jen Yee (PCMan) <pcman.tw (AT) gmail.com>, (C) 2006
*
* Copyright: See COPYING file that comes with this distribution
*
*/

#ifndef _EDIT_BOOKMARK_H_
#define _EDIT_BOOKMARK_H_

#include <gtk/gtk.h>

G_BEGIN_DECLS

gboolean edit_bookmarks( GtkWindow* parent );

G_END_DECLS

#endif

