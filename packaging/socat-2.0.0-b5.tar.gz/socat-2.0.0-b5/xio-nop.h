/* $Id: xio-socks.h,v 1.6 2004/06/06 19:03:28 gerhard Exp $ */
/* Copyright Gerhard Rieger 2006-2007 */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xio_nop_h_included
#define __xio_nop_h_included 1

extern const union xioaddr_desc *xioaddrs_nop[];

#endif /* !defined(__xio_nop_h_included) */
