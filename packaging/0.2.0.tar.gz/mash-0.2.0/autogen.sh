#!/bin/sh

REQUIRED_AUTOMAKE_VERSION=1.10 exec gnome-autogen.sh $@
